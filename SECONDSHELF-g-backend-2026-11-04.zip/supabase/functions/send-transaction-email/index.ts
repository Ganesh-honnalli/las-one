// Transactional email dispatch is intentionally disabled until a verified provider,
// sender domain, and recipient authorization are configured. Supabase Auth sends
// the real verification and password recovery emails.
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
serve((req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204 });
  return new Response(JSON.stringify({ error: "Transactional email is not configured. No email was sent." }), {
    status: 503,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
});
