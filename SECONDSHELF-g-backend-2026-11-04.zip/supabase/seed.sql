-- Production seed data only: categories and valuation rules. No sample accounts or transactions.
insert into public.valuation_rules(condition_name,max_percentage,description) values
('Like New',30,'Maximum estimate is 30% of original purchase price.'),
('Good',30,'Maximum estimate is 30% of original purchase price.'),
('Used',20,'Maximum estimate is 20% of original purchase price.'),
('Old or Damaged',15,'Maximum estimate is 15% of original purchase price.')
on conflict(condition_name) do update set max_percentage=excluded.max_percentage,description=excluded.description;
insert into public.categories(name,slug,description,display_order) values
('Engineering Books','engineering-books','Engineering and technology textbooks.',1),
('Degree Books','degree-books','Undergraduate and postgraduate textbooks.',2),
('PUC Books','puc-books','Pre-university textbooks.',3),
('Class 10th / SSLC Books','sslc-books','Secondary school textbooks.',4),
('Medical and Competitive Exam Books','medical-competitive-books','Medical and competitive examination books.',5),
('Story Books and Novels','story-books-novels','Fiction and general reading.',6),
('Other Educational Books','other-educational-books','Other educational titles.',7)
on conflict(name) do update set description=excluded.description,display_order=excluded.display_order;
